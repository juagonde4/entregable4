from silence.decorators import endpoint

@endpoint(
    route="/degrees",
    method="GET",
    sql="SELECT * FROM degrees",
)
def get_all():
    pass

###############################################################################

@endpoint(
    route="/degrees/$degreeId",
    method="GET",
    sql="SELECT * FROM degrees WHERE degreeId = $degreeId",
)
def get_by_id():
    pass

###############################################################################

@endpoint(
    route="/degrees",
    method="POST",
    sql="INSERT INTO degrees (degreeId, name,years) VALUES ($degreeId,$name, $years)",
)
def add(degreeId, name,years):
    pass

###############################################################################

@endpoint(
    route="/degrees/$degreeId",
    method="PUT",
    sql="UPDATE degrees SET degreeId = $degreeId,name = $name, years = $years WHERE degreeId = $degreeId",

)
def update(degreeId, name,years):
    pass

###############################################################################

@endpoint(
    route="/degrees/$degreeId",
    method="DELETE",
    sql="DELETE FROM degrees WHERE degreeId = $degreeId",
   
)
def delete():
    pass
