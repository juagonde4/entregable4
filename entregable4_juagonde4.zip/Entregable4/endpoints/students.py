from silence.decorators import endpoint

@endpoint(
    route="/students",
    method="GET",
    sql="SELECT * FROM students",
)
def get_all():
    pass

###############################################################################

@endpoint(
    route="/students/$studentId",
    method="GET",
    sql="SELECT * FROM students WHERE studentId = $studentId",
)
def get_by_id():
    pass

###############################################################################

@endpoint(
    route="/students",
    method="POST",
    sql="INSERT INTO subjects (studentId, accessMethod,dni,firstName,surname,birthDate,email) VALUES ($studentId,$accessMethod, $dni,$firstName,$surname,$birthDate,$email)",
)
def add(studentId, accessMethod,dni,firstName,surname,birthDate,email):
    pass

###############################################################################

@endpoint(
    route="/students/$studentId",
    method="PUT",
    sql="UPDATE students SET studentId=$studentId,accessMethod=$accessMethod,dni=$dni,firstName=$firstName,surname=$surname,birthDate=$birthDate email=$email WHERE studentId = $studentId",

)
def update(studentId, accessMethod,dni,firstName,surname,birthDate,email):
    pass

###############################################################################

@endpoint(
    route="/students/$studentId",
    method="DELETE",
    sql="DELETE FROM students WHERE studentId = $studentId",
   
)
def delete():
    pass
