from silence.decorators import endpoint

@endpoint(
    route="/groups",
    method="GET",
    sql="SELECT * FROM groups",
)
def get_all():
    pass

###############################################################################

@endpoint(
    route="/groups/$groupId",
    method="GET",
    sql="SELECT * FROM groups WHERE groupId = $groupId",
)
def get_by_id():
    pass

###############################################################################

@endpoint(
    route="/groups",
    method="POST",
    sql="INSERT INTO subjects (groupId, name,activity,year,subjectId,classroomId) VALUES ($groupId,$name, $activity,$year,$subjectId,$classroomId)",
)
def add(groupId, name,activity,year,subjectId,classroomId):
    pass

###############################################################################

@endpoint(
    route="/groups/$groupId",
    method="PUT",
    sql="UPDATE groups SET groupId=$groupId,name=$name,activity=$activity,year=$year,subjectId=$subjectId,classroomId=$classroomId WHERE groupId = $groupId",

)
def update(groupId, name,activity,year,subjectId,classroomId):
    pass

###############################################################################

@endpoint(
    route="/groups/$groupId",
    method="DELETE",
    sql="DELETE FROM groups WHERE groupId = $groupId",
   
)
def delete():
    pass
