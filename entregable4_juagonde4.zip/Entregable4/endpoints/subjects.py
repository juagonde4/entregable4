from silence.decorators import endpoint

@endpoint(
    route="/subjects",
    method="GET",
    sql="SELECT * FROM subjects",
)
def get_all():
    pass

###############################################################################

@endpoint(
    route="/subjects/$subjectId",
    method="GET",
    sql="SELECT * FROM subjects WHERE subjectId = $subjectId",
)
def get_by_id():
    pass

###############################################################################

@endpoint(
    route="/subjects",
    method="POST",
    sql="INSERT INTO subjects (subjectId, name,acronym,credits,course,type,degreeId,departmentId) VALUES ($subjectId,$name, $acronym,$credits,$course,$type,$degreeId,$departmentId)",
)
def add(subjectId, name,acronym,credits,course,type,degreeId,departmentId):
    pass

###############################################################################

@endpoint(
    route="/subjects/$subjectId",
    method="PUT",
    sql="UPDATE subjects SET subjectId=$subjectId,name=$name,acronym=$acronym,credits=$credits,course=$course,type=$type,degreeId=$degreeId,departmentId=$departmentId WHERE subjectId = $subjectId",

)
def update(subjectId, name,acronym,credits,course,type,degreeId,departmentId):
    pass

###############################################################################

@endpoint(
    route="/subjects/$subjectId",
    method="DELETE",
    sql="DELETE FROM subjects WHERE subjectId = $subjectId",
   
)
def delete():
    pass
