# Sample project
This project contains an example project that is downloaded by default using the `silence new` command.